# ImageOptimizer Pro

## Overview

ImageOptimizer Pro is a full-stack web application for image compression and optimization. It provides a user-friendly interface for uploading, compressing, and downloading optimized images with various quality settings. The application is built with a modern tech stack featuring React frontend, Express backend, and PostgreSQL database.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a traditional client-server architecture with clear separation between frontend and backend concerns:

- **Frontend**: React SPA with TypeScript, built using Vite
- **Backend**: Express.js REST API with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Tailwind CSS with shadcn/ui components
- **Image Processing**: Sharp library for server-side image manipulation

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with custom configuration for development and production
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **State Management**: TanStack React Query for server state
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Image Processing**: Sharp library for compression and format conversion
- **File Upload**: Multer for handling multipart form data
- **API Design**: RESTful endpoints with JSON responses

### Database Layer
- **Database**: PostgreSQL via Neon serverless
- **ORM**: Drizzle ORM with TypeScript-first approach
- **Schema**: Shared schema definitions between client and server
- **Migrations**: Drizzle Kit for database migrations

### UI/UX Components
- **Upload Interface**: Drag-and-drop file upload with validation
- **Compression Settings**: Interactive quality sliders and preset options
- **Image Comparison**: Before/after visual comparison with metrics
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **SEO Optimization**: Meta tags, structured data, and Open Graph support

## Data Flow

1. **Image Upload**: Client uploads images via multipart form data to `/api/compress`
2. **Validation**: Server validates file type, size, and compression parameters
3. **Processing**: Sharp library compresses images based on quality settings
4. **Storage**: Compression job metadata stored in PostgreSQL database
5. **Response**: Compressed image returned as base64 data with statistics
6. **Download**: Client converts base64 to blob for user download

### Database Schema
- **users**: User authentication and profile data
- **compression_jobs**: Tracking compression statistics and history

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **sharp**: High-performance image processing
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI component primitives

### Development Tools
- **TypeScript**: Static type checking
- **Vite**: Fast development and build tooling
- **Tailwind CSS**: Utility-first styling
- **ESLint/Prettier**: Code quality and formatting

### SEO and Analytics
- **react-helmet**: Dynamic meta tag management
- **Structured Data**: JSON-LD for search engine optimization
- **AdSense Integration**: Monetization through display advertisements

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds React app to static files in `dist/public`
- **Backend**: ESBuild bundles Express server to `dist/index.js`
- **Environment**: Supports both development and production configurations

### Environment Configuration
- **Development**: Hot module replacement with Vite dev server
- **Production**: Static file serving with Express
- **Database**: Environment-based connection strings

### Key Features
- **Image Format Support**: JPEG, PNG, WebP with intelligent format optimization
- **Quality Presets**: High, Medium, Low, and Custom compression levels
- **Batch Processing**: Multiple file upload and processing
- **Real-time Preview**: Immediate visual feedback with compression statistics
- **Mobile Responsive**: Optimized for all device sizes
- **Accessibility**: WCAG compliant with keyboard navigation support

The application prioritizes performance, user experience, and SEO optimization while maintaining a clean, maintainable codebase with strong type safety throughout.