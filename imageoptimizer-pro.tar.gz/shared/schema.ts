import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const compressionJobs = pgTable("compression_jobs", {
  id: serial("id").primaryKey(),
  originalFileName: text("original_file_name").notNull(),
  compressedFileName: text("compressed_file_name").notNull(),
  originalSize: integer("original_size").notNull(),
  compressedSize: integer("compressed_size").notNull(),
  compressionRatio: integer("compression_ratio").notNull(),
  quality: integer("quality").notNull(),
  format: text("format").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCompressionJobSchema = createInsertSchema(compressionJobs).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertCompressionJob = z.infer<typeof insertCompressionJobSchema>;
export type CompressionJob = typeof compressionJobs.$inferSelect;
