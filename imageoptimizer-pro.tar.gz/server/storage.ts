import { users, compressionJobs, type User, type InsertUser, type CompressionJob, type InsertCompressionJob } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createCompressionJob(job: InsertCompressionJob): Promise<CompressionJob>;
  getCompressionStats(): Promise<{ totalJobs: number; totalDataReduced: number; avgReduction: number }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private compressionJobs: Map<number, CompressionJob>;
  private currentUserId: number;
  private currentJobId: number;

  constructor() {
    this.users = new Map();
    this.compressionJobs = new Map();
    this.currentUserId = 1;
    this.currentJobId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createCompressionJob(insertJob: InsertCompressionJob): Promise<CompressionJob> {
    const id = this.currentJobId++;
    const job: CompressionJob = { 
      ...insertJob, 
      id, 
      createdAt: new Date() 
    };
    this.compressionJobs.set(id, job);
    return job;
  }

  async getCompressionStats(): Promise<{ totalJobs: number; totalDataReduced: number; avgReduction: number }> {
    const jobs = Array.from(this.compressionJobs.values());
    const totalJobs = jobs.length;
    const totalDataReduced = jobs.reduce((sum, job) => sum + (job.originalSize - job.compressedSize), 0);
    const avgReduction = jobs.length > 0 
      ? Math.round(jobs.reduce((sum, job) => sum + job.compressionRatio, 0) / jobs.length)
      : 0;

    return {
      totalJobs,
      totalDataReduced,
      avgReduction
    };
  }
}

export const storage = new MemStorage();
