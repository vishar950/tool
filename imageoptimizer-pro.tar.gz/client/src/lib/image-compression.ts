export interface CompressionOptions {
  quality: number;
  maxWidth?: number;
  maxHeight?: number;
  format?: 'jpeg' | 'png' | 'webp';
}

export interface CompressionResult {
  originalSize: number;
  compressedSize: number;
  compressionRatio: number;
  blob: Blob;
  dataUrl: string;
}

export class ImageCompressor {
  static async compressImage(
    file: File, 
    options: CompressionOptions
  ): Promise<CompressionResult> {
    return new Promise((resolve, reject) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();

      if (!ctx) {
        reject(new Error('Canvas context not available'));
        return;
      }

      img.onload = () => {
        try {
          // Calculate dimensions
          let { width, height } = img;
          
          if (options.maxWidth && width > options.maxWidth) {
            height = (height * options.maxWidth) / width;
            width = options.maxWidth;
          }
          
          if (options.maxHeight && height > options.maxHeight) {
            width = (width * options.maxHeight) / height;
            height = options.maxHeight;
          }

          // Set canvas dimensions
          canvas.width = width;
          canvas.height = height;

          // Draw and compress
          ctx.drawImage(img, 0, 0, width, height);

          // Determine output format
          const outputFormat = options.format || this.getOptimalFormat(file.type);
          const mimeType = `image/${outputFormat}`;
          const quality = options.quality / 100;

          canvas.toBlob(
            (blob) => {
              if (!blob) {
                reject(new Error('Failed to compress image'));
                return;
              }

              const compressionRatio = Math.round(
                ((file.size - blob.size) / file.size) * 100
              );

              const reader = new FileReader();
              reader.onload = () => {
                resolve({
                  originalSize: file.size,
                  compressedSize: blob.size,
                  compressionRatio,
                  blob,
                  dataUrl: reader.result as string,
                });
              };
              reader.onerror = () => reject(new Error('Failed to read compressed image'));
              reader.readAsDataURL(blob);
            },
            mimeType,
            quality
          );
        } catch (error) {
          reject(error);
        }
      };

      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = URL.createObjectURL(file);
    });
  }

  static getOptimalFormat(originalFormat: string): 'jpeg' | 'png' | 'webp' {
    // Simple format optimization logic
    if (originalFormat.includes('png')) {
      return 'png'; // Keep PNG for images that might need transparency
    }
    if (originalFormat.includes('webp')) {
      return 'webp'; // Keep WebP for best compression
    }
    return 'jpeg'; // Default to JPEG for photos
  }

  static async batchCompress(
    files: File[],
    options: CompressionOptions,
    progressCallback?: (progress: number) => void
  ): Promise<CompressionResult[]> {
    const results: CompressionResult[] = [];
    
    for (let i = 0; i < files.length; i++) {
      try {
        const result = await this.compressImage(files[i], options);
        results.push(result);
        
        if (progressCallback) {
          progressCallback(((i + 1) / files.length) * 100);
        }
      } catch (error) {
        console.error(`Failed to compress ${files[i].name}:`, error);
        // Continue with other files even if one fails
      }
    }
    
    return results;
  }

  static formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  static downloadBlob(blob: Blob, filename: string): void {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
