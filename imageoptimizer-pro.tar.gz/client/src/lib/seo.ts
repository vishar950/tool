export interface SEOData {
  title: string;
  description: string;
  keywords: string[];
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  twitterTitle?: string;
  twitterDescription?: string;
  twitterImage?: string;
  canonicalUrl?: string;
  structuredData?: object;
}

export class SEOManager {
  static updateMetaTags(seoData: SEOData): void {
    // Update title
    document.title = seoData.title;

    // Update meta tags
    this.updateMetaTag('description', seoData.description);
    this.updateMetaTag('keywords', seoData.keywords.join(', '));
    this.updateMetaTag('robots', 'index, follow');

    // Update Open Graph tags
    if (seoData.ogTitle) {
      this.updateMetaProperty('og:title', seoData.ogTitle);
    }
    if (seoData.ogDescription) {
      this.updateMetaProperty('og:description', seoData.ogDescription);
    }
    if (seoData.ogImage) {
      this.updateMetaProperty('og:image', seoData.ogImage);
    }
    
    this.updateMetaProperty('og:type', 'website');
    this.updateMetaProperty('og:url', window.location.href);

    // Update Twitter Card tags
    this.updateMetaProperty('twitter:card', 'summary_large_image');
    if (seoData.twitterTitle) {
      this.updateMetaProperty('twitter:title', seoData.twitterTitle);
    }
    if (seoData.twitterDescription) {
      this.updateMetaProperty('twitter:description', seoData.twitterDescription);
    }
    if (seoData.twitterImage) {
      this.updateMetaProperty('twitter:image', seoData.twitterImage);
    }

    // Update canonical URL
    if (seoData.canonicalUrl) {
      this.updateCanonicalUrl(seoData.canonicalUrl);
    }

    // Update structured data
    if (seoData.structuredData) {
      this.updateStructuredData(seoData.structuredData);
    }
  }

  private static updateMetaTag(name: string, content: string): void {
    let meta = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement;
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = name;
      document.head.appendChild(meta);
    }
    meta.content = content;
  }

  private static updateMetaProperty(property: string, content: string): void {
    let meta = document.querySelector(`meta[property="${property}"]`) as HTMLMetaElement;
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('property', property);
      document.head.appendChild(meta);
    }
    meta.content = content;
  }

  private static updateCanonicalUrl(url: string): void {
    let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    if (!link) {
      link = document.createElement('link');
      link.rel = 'canonical';
      document.head.appendChild(link);
    }
    link.href = url;
  }

  private static updateStructuredData(data: object): void {
    // Remove existing structured data
    const existingScript = document.querySelector('script[type="application/ld+json"]');
    if (existingScript) {
      existingScript.remove();
    }

    // Add new structured data
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify(data);
    document.head.appendChild(script);
  }

  static generateImageCompressionSchema(stats: {
    totalImages: string;
    dataReduced: string;
    avgReduction: string;
  }): object {
    return {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "name": "ImageOptimizer Pro",
      "description": "Free online image compression tool that reduces file sizes while maintaining quality",
      "url": window.location.origin,
      "applicationCategory": "MultimediaApplication",
      "operatingSystem": "Any",
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "USD"
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.9",
        "ratingCount": "25000"
      },
      "featureList": [
        "JPEG compression",
        "PNG optimization", 
        "WebP conversion",
        "Batch processing",
        "Drag and drop upload",
        "Mobile responsive"
      ]
    };
  }

  static getDefaultSEOData(): SEOData {
    return {
      title: "ImageOptimizer Pro - Free Online Image Compression Tool | Reduce File Size by 80%",
      description: "Compress images online for free. Reduce JPEG, PNG, and WebP file sizes by up to 80% while maintaining quality. Fast, secure, and SEO-friendly image optimization tool.",
      keywords: [
        "image compression",
        "optimize images", 
        "reduce file size",
        "JPEG compression",
        "PNG optimizer",
        "WebP converter",
        "SEO images",
        "web optimization",
        "image optimization tool"
      ],
      ogTitle: "ImageOptimizer Pro - Free Online Image Compression Tool",
      ogDescription: "Compress images online for free. Reduce file sizes by up to 80% while maintaining quality.",
      twitterTitle: "ImageOptimizer Pro - Free Online Image Compression Tool",
      twitterDescription: "Compress images online for free. Reduce file sizes by up to 80% while maintaining quality.",
      canonicalUrl: window.location.origin
    };
  }
}
