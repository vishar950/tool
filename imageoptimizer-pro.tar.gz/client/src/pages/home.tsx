import { useState } from "react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import UploadArea from "@/components/upload-area";
import CompressionSettings from "@/components/compression-settings";
import ImageComparison from "@/components/image-comparison";
import AdSpace from "@/components/ad-space";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

interface ProcessedImage {
  original: {
    size: number;
    filename: string;
    data?: string;
  };
  compressed: {
    size: number;
    filename: string;
    base64: string;
  };
  compressionRatio: number;
  quality: number;
  format: string;
}

export default function Home() {
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [processedImages, setProcessedImages] = useState<ProcessedImage[]>([]);
  const [quality, setQuality] = useState(80);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeQualityLevel, setActiveQualityLevel] = useState("high");

  const { data: stats } = useQuery({
    queryKey: ['/api/stats'],
  });

  const handleFilesSelected = (files: File[]) => {
    setUploadedFiles(files);
  };

  const handleCompress = async () => {
    if (uploadedFiles.length === 0) return;

    setIsProcessing(true);
    const newProcessedImages: ProcessedImage[] = [];

    try {
      if (uploadedFiles.length === 1) {
        // Single file compression
        const formData = new FormData();
        formData.append('image', uploadedFiles[0]);
        formData.append('quality', quality.toString());

        const response = await fetch('/api/compress', {
          method: 'POST',
          body: formData,
        });

        if (!response.ok) {
          throw new Error('Compression failed');
        }

        const result = await response.json();
        newProcessedImages.push(result);
      } else {
        // Batch compression
        const formData = new FormData();
        uploadedFiles.forEach(file => {
          formData.append('images', file);
        });
        formData.append('quality', quality.toString());

        const response = await fetch('/api/compress-batch', {
          method: 'POST',
          body: formData,
        });

        if (!response.ok) {
          throw new Error('Batch compression failed');
        }

        const result = await response.json();
        newProcessedImages.push(...result.results.filter((r: any) => r.success));
      }

      setProcessedImages(newProcessedImages);
    } catch (error) {
      console.error('Compression error:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadImage = (base64Data: string, filename: string) => {
    const link = document.createElement('a');
    link.href = base64Data;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadAll = () => {
    processedImages.forEach(image => {
      downloadImage(image.compressed.base64, image.compressed.filename);
    });
  };

  return (
    <div className="min-h-screen bg-bg-light">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-white py-12 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl lg:text-6xl font-google font-bold text-text-dark mb-6">
              Compress Images <span className="text-google-blue">Without Quality Loss</span>
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Reduce your image file sizes by up to 80% while maintaining perfect quality. Support for JPEG, PNG, and WebP formats with batch processing capabilities.
            </p>
          </div>

          <div className="grid lg:grid-cols-12 gap-8 items-start">
            {/* Upload Area */}
            <div className="lg:col-span-8">
              <UploadArea 
                onFilesSelected={handleFilesSelected}
                uploadedFiles={uploadedFiles}
                isProcessing={isProcessing}
              />

              <CompressionSettings
                quality={quality}
                onQualityChange={setQuality}
                activeLevel={activeQualityLevel}
                onLevelChange={setActiveQualityLevel}
              />

              {uploadedFiles.length > 0 && (
                <div className="mt-8 text-center">
                  <Button
                    onClick={handleCompress}
                    disabled={isProcessing}
                    className="bg-google-blue hover:bg-google-blue text-white px-8 py-4 text-lg"
                  >
                    {isProcessing ? (
                      <>
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                        Compressing...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-compress-alt mr-2"></i>
                        Compress {uploadedFiles.length} Image{uploadedFiles.length > 1 ? 's' : ''}
                      </>
                    )}
                  </Button>
                </div>
              )}
            </div>

            {/* Advertisement Space */}
            <div className="lg:col-span-4">
              <AdSpace type="sidebar" />
            </div>
          </div>
        </div>
      </section>

      {/* Results Section */}
      {processedImages.length > 0 && (
        <section className="bg-gray-50 py-12 lg:py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-google font-bold text-text-dark mb-4">
                Compression Results
              </h3>
              <p className="text-lg text-gray-600">
                Compare your original and optimized images
              </p>
            </div>

            <div className="space-y-8">
              {processedImages.map((image, index) => (
                <ImageComparison
                  key={index}
                  processedImage={image}
                  onDownload={downloadImage}
                />
              ))}
            </div>

            {processedImages.length > 1 && (
              <div className="mt-8 text-center">
                <Button
                  onClick={downloadAll}
                  className="bg-success-green hover:bg-success-green text-white px-6 py-3"
                >
                  <i className="fas fa-download mr-2"></i>
                  Download All Images
                </Button>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Features Section */}
      <section className="bg-white py-12 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl lg:text-4xl font-google font-bold text-text-dark mb-6">
              Why Choose ImageOptimizer Pro?
            </h3>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our advanced compression algorithms deliver superior results while maintaining the highest quality standards.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="text-google-blue text-4xl mb-4">
                  <i className="fas fa-bolt"></i>
                </div>
                <h4 className="text-xl font-google font-semibold text-text-dark mb-3">Lightning Fast</h4>
                <p className="text-gray-600">
                  Process images in seconds with our optimized compression engine. No waiting, no delays.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="text-success-green text-4xl mb-4">
                  <i className="fas fa-shield-alt"></i>
                </div>
                <h4 className="text-xl font-google font-semibold text-text-dark mb-3">100% Secure</h4>
                <p className="text-gray-600">
                  Your images are processed securely and never stored on our servers. Complete privacy guaranteed.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="text-google-blue text-4xl mb-4">
                  <i className="fas fa-layer-group"></i>
                </div>
                <h4 className="text-xl font-google font-semibold text-text-dark mb-3">Batch Processing</h4>
                <p className="text-gray-600">
                  Compress up to 20 images simultaneously. Perfect for bulk optimization projects.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="text-warning-red text-4xl mb-4">
                  <i className="fas fa-mobile-alt"></i>
                </div>
                <h4 className="text-xl font-google font-semibold text-text-dark mb-3">Mobile Friendly</h4>
                <p className="text-gray-600">
                  Works perfectly on all devices. Compress images on-the-go from your smartphone or tablet.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="text-success-green text-4xl mb-4">
                  <i className="fas fa-file-image"></i>
                </div>
                <h4 className="text-xl font-google font-semibold text-text-dark mb-3">Multiple Formats</h4>
                <p className="text-gray-600">
                  Support for JPEG, PNG, and WebP formats with intelligent format conversion suggestions.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="text-google-blue text-4xl mb-4">
                  <i className="fas fa-chart-line"></i>
                </div>
                <h4 className="text-xl font-google font-semibold text-text-dark mb-3">SEO Optimized</h4>
                <p className="text-gray-600">
                  Automatically optimize images for web performance and better search engine rankings.
                </p>
              </CardContent>
            </Card>
          </div>

          <AdSpace type="horizontal" />
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gray-50 py-12 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl lg:text-4xl font-google font-bold text-text-dark mb-6">
              Trusted by Millions
            </h3>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Join millions of users who have optimized their images with our professional-grade compression tool.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-google-blue mb-2">
                {stats?.totalImages || "2.5M+"}
              </div>
              <div className="text-gray-600">Images Processed</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-success-green mb-2">
                {stats?.dataReduced || "15TB+"}
              </div>
              <div className="text-gray-600">Data Reduced</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-warning-red mb-2">
                {stats?.avgReduction || "73%"}
              </div>
              <div className="text-gray-600">Average Reduction</div>
            </div>
            <div className="text-center">
              <div className="text-4xl lg:text-5xl font-bold text-google-blue mb-2">
                {stats?.userSatisfaction || "99.8%"}
              </div>
              <div className="text-gray-600">User Satisfaction</div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <AdSpace type="medium" />
            <AdSpace type="medium" />
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
