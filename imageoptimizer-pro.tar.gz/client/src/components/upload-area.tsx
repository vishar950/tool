import { useCallback, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface UploadAreaProps {
  onFilesSelected: (files: File[]) => void;
  uploadedFiles: File[];
  isProcessing: boolean;
}

export default function UploadArea({ onFilesSelected, uploadedFiles, isProcessing }: UploadAreaProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const { toast } = useToast();

  const validateFiles = (files: FileList | File[]): File[] => {
    const validFiles: File[] = [];
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    const maxSize = 10 * 1024 * 1024; // 10MB
    const maxFiles = 20;

    const fileArray = Array.from(files);

    if (fileArray.length > maxFiles) {
      toast({
        title: "Too many files",
        description: `You can only upload up to ${maxFiles} files at once.`,
        variant: "destructive",
      });
      return [];
    }

    for (const file of fileArray) {
      if (!allowedTypes.includes(file.type)) {
        toast({
          title: "Invalid file type",
          description: `${file.name} is not a supported format. Please use JPEG, PNG, or WebP.`,
          variant: "destructive",
        });
        continue;
      }

      if (file.size > maxSize) {
        toast({
          title: "File too large",
          description: `${file.name} is larger than 10MB. Please use a smaller file.`,
          variant: "destructive",
        });
        continue;
      }

      validFiles.push(file);
    }

    return validFiles;
  };

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const validFiles = validateFiles(e.target.files);
      if (validFiles.length > 0) {
        onFilesSelected(validFiles);
        toast({
          title: "Files selected",
          description: `${validFiles.length} file${validFiles.length > 1 ? 's' : ''} ready for compression.`,
        });
      }
    }
  }, [onFilesSelected, toast]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const validFiles = validateFiles(e.dataTransfer.files);
      if (validFiles.length > 0) {
        onFilesSelected(validFiles);
        toast({
          title: "Files uploaded",
          description: `${validFiles.length} file${validFiles.length > 1 ? 's' : ''} ready for compression.`,
        });
      }
    }
  }, [onFilesSelected, toast]);

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const removeFile = (index: number) => {
    const newFiles = uploadedFiles.filter((_, i) => i !== index);
    onFilesSelected(newFiles);
  };

  return (
    <div className="space-y-6">
      <Card 
        className={`border-2 border-dashed transition-all duration-300 ${
          isDragOver ? 'border-google-blue bg-blue-50' : 'border-gray-300 hover:border-google-blue'
        } ${isProcessing ? 'opacity-50 pointer-events-none' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <CardContent className="p-8 lg:p-12 text-center">
          <div className="mb-6">
            <i className="fas fa-cloud-upload-alt text-6xl text-google-blue mb-4"></i>
            <h3 className="text-2xl font-google font-semibold text-text-dark mb-2">
              Drag & Drop Your Images Here
            </h3>
            <p className="text-gray-600">
              Or click to browse files from your device
            </p>
          </div>
          
          <input
            type="file"
            multiple
            accept="image/jpeg,image/png,image/webp"
            onChange={handleFileSelect}
            className="hidden"
            id="file-upload"
            disabled={isProcessing}
          />
          
          <Button 
            asChild
            className="bg-google-blue hover:bg-google-blue text-white px-8 py-4 mb-6"
            disabled={isProcessing}
          >
            <label htmlFor="file-upload" className="cursor-pointer">
              <i className="fas fa-folder-open mr-2"></i>
              Select Images
            </label>
          </Button>
          
          <div className="text-sm text-gray-500 space-y-1">
            <p>Supports: JPEG, PNG, WebP • Max size: 10MB per file</p>
            <p>Process up to 20 images simultaneously</p>
          </div>
        </CardContent>
      </Card>

      {/* Selected Files Display */}
      {uploadedFiles.length > 0 && (
        <Card>
          <CardContent className="p-6">
            <h4 className="text-lg font-google font-semibold mb-4">
              Selected Files ({uploadedFiles.length})
            </h4>
            <div className="space-y-3">
              {uploadedFiles.map((file, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-image text-google-blue"></i>
                    <div>
                      <div className="font-medium text-text-dark">{file.name}</div>
                      <div className="text-sm text-gray-600">{formatFileSize(file.size)}</div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile(index)}
                    disabled={isProcessing}
                    className="text-warning-red hover:text-warning-red hover:bg-red-50"
                  >
                    <i className="fas fa-times"></i>
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
