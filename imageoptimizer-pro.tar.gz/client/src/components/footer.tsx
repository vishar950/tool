export default function Footer() {
  return (
    <footer className="bg-text-dark text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <h4 className="text-xl font-google font-bold mb-4 text-google-blue">
              <i className="fas fa-compress-alt mr-2"></i>
              ImageOptimizer Pro
            </h4>
            <p className="text-gray-300 mb-4">
              Professional image compression tool trusted by millions of users worldwide. Optimize your images for web performance and SEO.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-twitter text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-facebook text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <i className="fab fa-linkedin text-xl"></i>
              </a>
            </div>
          </div>

          <div>
            <h5 className="font-google font-semibold mb-4">Tools</h5>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">JPEG Compressor</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">PNG Optimizer</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">WebP Converter</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Batch Processor</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-google font-semibold mb-4">Resources</h5>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Image SEO Guide</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Web Performance Tips</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Compression Comparison</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">API Documentation</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-google font-semibold mb-4">Support</h5>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Help Center</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 ImageOptimizer Pro. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">Privacy</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">Terms</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">Cookies</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
