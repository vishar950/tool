import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-google font-bold text-google-blue">
                <i className="fas fa-compress-alt mr-2"></i>
                ImageOptimizer Pro
              </h1>
            </div>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#features" className="text-text-dark hover:text-google-blue transition-colors font-medium">
              Features
            </a>
            <a href="#how-it-works" className="text-text-dark hover:text-google-blue transition-colors font-medium">
              How It Works
            </a>
            <a href="#pricing" className="text-text-dark hover:text-google-blue transition-colors font-medium">
              Pricing
            </a>
            <a href="#support" className="text-text-dark hover:text-google-blue transition-colors font-medium">
              Support
            </a>
          </nav>
          
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-text-dark hover:text-google-blue"
            >
              <i className="fas fa-bars text-xl"></i>
            </Button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 space-y-2">
            <a href="#features" className="block px-3 py-2 text-text-dark hover:text-google-blue transition-colors font-medium">
              Features
            </a>
            <a href="#how-it-works" className="block px-3 py-2 text-text-dark hover:text-google-blue transition-colors font-medium">
              How It Works
            </a>
            <a href="#pricing" className="block px-3 py-2 text-text-dark hover:text-google-blue transition-colors font-medium">
              Pricing
            </a>
            <a href="#support" className="block px-3 py-2 text-text-dark hover:text-google-blue transition-colors font-medium">
              Support
            </a>
          </div>
        )}
      </div>
    </header>
  );
}
