import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";

interface CompressionSettingsProps {
  quality: number;
  onQualityChange: (quality: number) => void;
  activeLevel: string;
  onLevelChange: (level: string) => void;
}

const qualityLevels = [
  { id: 'high', name: 'High', quality: 85, reduction: '~70%' },
  { id: 'medium', name: 'Medium', quality: 70, reduction: '~55%' },
  { id: 'low', name: 'Low', quality: 50, reduction: '~40%' },
  { id: 'custom', name: 'Custom', quality: 80, reduction: 'Variable' },
];

export default function CompressionSettings({ 
  quality, 
  onQualityChange, 
  activeLevel, 
  onLevelChange 
}: CompressionSettingsProps) {

  const handleLevelSelect = (level: typeof qualityLevels[0]) => {
    onLevelChange(level.id);
    if (level.id !== 'custom') {
      onQualityChange(level.quality);
    }
  };

  return (
    <Card className="mt-8">
      <CardContent className="p-6">
        <h4 className="text-lg font-google font-semibold mb-4">Compression Settings</h4>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {qualityLevels.map((level) => (
            <div
              key={level.id}
              className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                activeLevel === level.id
                  ? 'border-google-blue bg-blue-50'
                  : 'border-gray-200 hover:border-google-blue'
              }`}
              onClick={() => handleLevelSelect(level)}
            >
              <div className="text-center">
                <div className="text-2xl font-bold text-google-blue mb-1">
                  {level.name}
                </div>
                <div className="text-sm text-gray-600">
                  {level.id === 'custom' ? `${quality}% quality` : `${level.quality}% quality`}
                </div>
                <div className="text-xs text-success-green mt-1">
                  {level.reduction}
                </div>
              </div>
            </div>
          ))}
        </div>

        {activeLevel === 'custom' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-text-dark">
                Custom Quality: {quality}%
              </label>
              <div className="text-xs text-gray-500">
                Higher = Better quality, Larger file
              </div>
            </div>
            <Slider
              value={[quality]}
              onValueChange={(value) => onQualityChange(value[0])}
              min={1}
              max={100}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>Smallest (1%)</span>
              <span>Balanced (50%)</span>
              <span>Highest (100%)</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
