import { useEffect } from "react";

interface AdSpaceProps {
  type: 'sidebar' | 'horizontal' | 'medium' | 'banner';
  className?: string;
}

export default function AdSpace({ type, className = "" }: AdSpaceProps) {
  const adConfig = {
    sidebar: {
      width: '300px',
      height: '600px',
      slot: '1234567890',
      format: 'auto'
    },
    horizontal: {
      width: '100%',
      height: '90px',
      slot: '0987654321',
      format: 'horizontal'
    },
    medium: {
      width: '336px',
      height: '280px',
      slot: '1122334455',
      format: 'auto'
    },
    banner: {
      width: '728px',
      height: '90px',
      slot: '5544332211',
      format: 'horizontal'
    }
  };

  const config = adConfig[type];
  const clientId = import.meta.env.VITE_ADSENSE_CLIENT_ID || 'ca-pub-XXXXXXXXXXXXXXXXX';

  useEffect(() => {
    try {
      // Initialize AdSense
      if (typeof window !== 'undefined' && (window as any).adsbygoogle) {
        ((window as any).adsbygoogle = (window as any).adsbygoogle || []).push({});
      }
    } catch (error) {
      console.error('AdSense initialization error:', error);
    }
  }, []);

  return (
    <div className={`bg-white rounded-xl shadow-lg p-6 ${className}`}>
      <div className="text-center mb-4">
        <span className="text-xs text-gray-500 uppercase tracking-wide">Advertisement</span>
      </div>
      
      {/* Google AdSense Ad Unit */}
      <ins 
        className="adsbygoogle"
        style={{ 
          display: 'block',
          width: config.width,
          height: config.height 
        }}
        data-ad-client={clientId}
        data-ad-slot={config.slot}
        data-ad-format={config.format}
        data-full-width-responsive="true"
      />
      
      {/* Fallback/Mock Display for Development */}
      {process.env.NODE_ENV === 'development' && (
        <div 
          className="bg-gray-100 rounded-lg flex items-center justify-center"
          style={{ 
            width: config.width === '100%' ? '100%' : config.width,
            height: config.height 
          }}
        >
          <div className="text-center text-gray-500">
            <i className="fas fa-ad text-2xl mb-2"></i>
            <p className="text-sm">
              Advertisement Space<br/>
              {config.width} × {config.height}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
