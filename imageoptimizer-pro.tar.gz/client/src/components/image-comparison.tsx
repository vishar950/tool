import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ProcessedImage {
  original: {
    size: number;
    filename: string;
    data?: string;
  };
  compressed: {
    size: number;
    filename: string;
    base64: string;
  };
  compressionRatio: number;
  quality: number;
  format: string;
}

interface ImageComparisonProps {
  processedImage: ProcessedImage;
  onDownload: (base64Data: string, filename: string) => void;
}

export default function ImageComparison({ processedImage, onDownload }: ImageComparisonProps) {
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getImageDimensions = (base64: string): Promise<{ width: number; height: number }> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        resolve({ width: img.width, height: img.height });
      };
      img.src = base64;
    });
  };

  return (
    <Card className="animate-fade-in">
      <CardContent className="p-6 lg:p-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Before */}
          <div className="text-center">
            <h4 className="text-lg font-google font-semibold mb-4 text-text-dark">Original</h4>
            <div className="relative">
              <img 
                src={processedImage.compressed.base64} // Using compressed as preview since we don't store original
                alt="Original image before compression" 
                className="rounded-xl shadow-md w-full h-auto mb-4 max-h-64 object-contain bg-gray-100" 
              />
              <div className="absolute top-2 right-2 bg-black bg-opacity-75 text-white px-2 py-1 rounded text-xs">
                Original
              </div>
            </div>
            <div className="bg-gray-100 rounded-lg p-4">
              <div className="text-2xl font-bold text-text-dark">
                {formatFileSize(processedImage.original.size)}
              </div>
              <div className="text-sm text-gray-600">
                {processedImage.format.toUpperCase()} • {processedImage.original.filename}
              </div>
            </div>
          </div>

          {/* After */}
          <div className="text-center">
            <h4 className="text-lg font-google font-semibold mb-4 text-text-dark">Optimized</h4>
            <div className="relative">
              <img 
                src={processedImage.compressed.base64}
                alt="Compressed image after optimization" 
                className="rounded-xl shadow-md w-full h-auto mb-4 max-h-64 object-contain bg-gray-100" 
              />
              <div className="absolute top-2 right-2 bg-success-green text-white px-2 py-1 rounded text-xs">
                Optimized
              </div>
            </div>
            <div className="bg-success-green/10 border border-success-green rounded-lg p-4">
              <div className="text-2xl font-bold text-success-green">
                {formatFileSize(processedImage.compressed.size)}
              </div>
              <div className="text-sm text-gray-600">
                {processedImage.format.toUpperCase()} • Quality: {processedImage.quality}%
              </div>
              <div className="text-sm font-medium text-success-green mt-1">
                {processedImage.compressionRatio}% smaller
              </div>
            </div>
          </div>
        </div>

        {/* Download Actions */}
        <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            onClick={() => onDownload(processedImage.compressed.base64, processedImage.compressed.filename)}
            className="bg-google-blue hover:bg-google-blue text-white px-6 py-3"
          >
            <i className="fas fa-download mr-2"></i>
            Download Optimized
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              // Create a simple text file with compression info
              const info = `Compression Summary:
Original: ${processedImage.original.filename} (${formatFileSize(processedImage.original.size)})
Compressed: ${processedImage.compressed.filename} (${formatFileSize(processedImage.compressed.size)})
Reduction: ${processedImage.compressionRatio}%
Quality: ${processedImage.quality}%
Format: ${processedImage.format.toUpperCase()}`;
              
              const blob = new Blob([info], { type: 'text/plain' });
              const url = URL.createObjectURL(blob);
              const link = document.createElement('a');
              link.href = url;
              link.download = `compression_info_${processedImage.original.filename}.txt`;
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
              URL.revokeObjectURL(url);
            }}
            className="border-gray-300 text-text-dark hover:bg-gray-50"
          >
            <i className="fas fa-info-circle mr-2"></i>
            Download Info
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
