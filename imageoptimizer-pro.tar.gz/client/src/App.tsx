import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Helmet } from "react-helmet";
import Home from "@/pages/home";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home}/>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Helmet>
          <title>ImageOptimizer Pro - Free Online Image Compression Tool | Reduce File Size by 80%</title>
          <meta name="description" content="Compress images online for free. Reduce JPEG, PNG, and WebP file sizes by up to 80% while maintaining quality. Fast, secure, and SEO-friendly image optimization tool." />
          <meta name="keywords" content="image compression, optimize images, reduce file size, JPEG compression, PNG optimizer, WebP converter, SEO images" />
          <meta name="robots" content="index, follow" />
          <link rel="canonical" href="https://imageoptimizer.pro" />
          
          {/* Open Graph / Facebook */}
          <meta property="og:type" content="website" />
          <meta property="og:url" content="https://imageoptimizer.pro" />
          <meta property="og:title" content="ImageOptimizer Pro - Free Online Image Compression Tool" />
          <meta property="og:description" content="Compress images online for free. Reduce file sizes by up to 80% while maintaining quality." />
          <meta property="og:image" content="https://imageoptimizer.pro/og-image.jpg" />

          {/* Twitter */}
          <meta property="twitter:card" content="summary_large_image" />
          <meta property="twitter:url" content="https://imageoptimizer.pro" />
          <meta property="twitter:title" content="ImageOptimizer Pro - Free Online Image Compression Tool" />
          <meta property="twitter:description" content="Compress images online for free. Reduce file sizes by up to 80% while maintaining quality." />
          <meta property="twitter:image" content="https://imageoptimizer.pro/twitter-image.jpg" />

          {/* Structured Data */}
          <script type="application/ld+json">
            {JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "ImageOptimizer Pro",
              "description": "Free online image compression tool that reduces file sizes while maintaining quality",
              "url": "https://imageoptimizer.pro",
              "applicationCategory": "MultimediaApplication",
              "operatingSystem": "Any",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              }
            })}
          </script>

          {/* Google Fonts */}
          <link href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet" />
          
          {/* Font Awesome */}
          <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
          
          {/* Google AdSense */}
          <script async src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${import.meta.env.VITE_ADSENSE_CLIENT_ID || 'ca-pub-XXXXXXXXXXXXXXXXX'}`} crossorigin="anonymous"></script>
        </Helmet>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
